import 'package:animated_splash_screen/animated_splash_screen.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'child/bottom_page.dart';
import 'child/child_login_screen.dart';
import 'db/share_pref.dart';
import 'parent/parent_home_screen.dart';
import 'utils/constants.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: const FirebaseOptions(
      apiKey: 'AIzaSyBcYL3eovYylXaCI_JZuGymRsmOjMa3EMA',
      appId: '1:213071786703:android:351df1cbbd53bb39c37dba',
      messagingSenderId: '213071786703',
      projectId: 'women-safety-sos-7496c',
      storageBucket: "gs://women-safety-sos-7496c.appspot.com",
    ),
  );
  await MySharedPrefference.init();
  //await initializeService();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Woman Safety Application',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        textTheme: GoogleFonts.firaSansTextTheme(
          Theme.of(context).textTheme,
        ),
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: AnimatedSplashScreen(
        duration: 4000,
        splash: Image.asset('assets/splash.jpg'),
        nextScreen: FutureBuilder(
          future: MySharedPrefference.getUserType(),
          builder: (BuildContext context, AsyncSnapshot<String> snapshot) {
            if (snapshot.data == "") {
              return const LoginScreen();
            }
            if (snapshot.data == "child") {
              return const BottomPage();
            }
            if (snapshot.data == "parent") {
              return const ParentHomeScreen();
            }
            return progressIndicator(context);
          },
        ),
        splashTransition: SplashTransition.fadeTransition,
        backgroundColor: Colors.white,
        splashIconSize: 250.0,
      ),
    );
  }
}
