import 'dart:io';

bool isCupertino() {
  return Platform.isIOS || Platform.isMacOS;
}
