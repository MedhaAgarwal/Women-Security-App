// ignore_for_file: file_names

import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:safety/utils/quotes.dart';
import 'package:safety/widgets/home_widgets/safewebview.dart';

class CustomCarousel extends StatelessWidget {
  // ignore: use_key_in_widget_constructors
  const CustomCarousel({Key? key});

  void navigateToRoute(BuildContext context, Widget route) {
    Navigator.push(context, CupertinoPageRoute(builder: (context) => route));
  }

  @override
  Widget build(BuildContext context) {
    return CarouselSlider(
      options: CarouselOptions(
        aspectRatio: 2.0,
        autoPlay: true,
        enlargeCenterPage: true,
      ),
      items: List.generate(
        imageSliders.length,
        (index) => Card(
          elevation: 5.0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          child: InkWell(
            onTap: () {
              if (index == 0) {
                navigateToRoute(
                    context,
                    const SafeWebView(
                        url:
                            "https://unb.com.bd/category/Bangladesh/legendary-women-in-bangladesh-with-pioneering-contribution-in-diverse-fields/65830#:~:text=Sheikh%20Hasina%20Begum%20Sufia%20Kamal%20Begum%20Rokeya%20Bibi,Most%20Influential%20Women%20in%20Bangladesh%20Famous%20Bangladeshi%20Women"));
              } else if (index == 1) {
                navigateToRoute(
                    context,
                    const SafeWebView(
                        url:
                            "https://plan-international.org/ending-violence/16-ways-end-violence-girls"));
              } else if (index == 2) {
                navigateToRoute(
                    context,
                    const SafeWebView(
                        url:
                            "https://www.healthline.com/health/womens-health/self-defense-tips-escape"));
              } else {
                navigateToRoute(
                    context,
                    const SafeWebView(
                        url:
                            "https://www.healthline.com/health/womens-health/self-defense-tips-escape"));
              }
            },
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                image: DecorationImage(
                  fit: BoxFit.cover,
                  image: NetworkImage(imageSliders[index]),
                ),
              ),
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  gradient: LinearGradient(colors: [
                    Colors.black.withOpacity(0.5),
                    Colors.transparent,
                  ]),
                ),
                child: Align(
                  alignment: Alignment.bottomLeft,
                  child: Padding(
                    padding: const EdgeInsets.only(bottom: 8, left: 8),
                    child: Text(
                      articleTitle[index],
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        fontSize: MediaQuery.of(context).size.width * 0.05,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
