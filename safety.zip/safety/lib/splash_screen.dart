// ignore_for_file: use_build_context_synchronously

import 'package:animated_splash_screen/animated_splash_screen.dart';
import 'package:flutter/material.dart';
import 'package:safety/parent/parent_home_screen.dart';
import 'package:safety/utils/constants.dart';
import 'child/bottom_page.dart';
import 'child/child_login_screen.dart';
import 'package:page_transition/page_transition.dart';

import 'db/share_pref.dart';

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedSplashScreen.withScreenFunction(
      splash: 'assets/splash.jpg', // Replace with your splash image path
      screenFunction: () async {
        await MySharedPrefference.init();

        String? userType = await MySharedPrefference.getUserType();
        if (userType == null || userType == "") {
          return const LoginScreen();
        } else if (userType == "child") {
          return const BottomPage();
        } else if (userType == "parent") {
          return const ParentHomeScreen();
        } else {
          return progressIndicator(context);
        }
      },
      splashTransition: SplashTransition.rotationTransition,
      pageTransitionType: PageTransitionType.scale,
      duration: 3000,
    );
  }
}
