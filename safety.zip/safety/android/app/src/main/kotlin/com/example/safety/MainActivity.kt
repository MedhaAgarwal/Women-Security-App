package com.example.safety

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
